# Pyarmor 8.5.12 (trial), 000000, 2024-10-05T17:12:24.441998
from .pyarmor_runtime import __pyarmor__
