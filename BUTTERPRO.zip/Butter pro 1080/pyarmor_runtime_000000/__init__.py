# Pyarmor 8.5.12 (trial), 000000, 2024-10-05T17:09:14.172118
from .pyarmor_runtime import __pyarmor__
